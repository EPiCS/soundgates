/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_2592010699;
char *STD_STANDARD;
char *IEEE_P_3499444699;
char *IEEE_P_0774719531;
char *IEEE_P_1242562249;
char *STD_TEXTIO;
char *IEEE_P_3564397177;
char *VL_P_2533777724;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000004134447467_2073120511_init();
    unisims_ver_m_00000000003927721830_1593237687_init();
    unisims_ver_m_00000000003317509437_1759035934_init();
    unisims_ver_m_00000000002601448656_3367321443_init();
    unisims_ver_m_00000000001773747898_0257217429_init();
    unisims_ver_m_00000000001773747898_0374334164_init();
    unisims_ver_m_00000000001773747898_2336946039_init();
    unisims_ver_m_00000000003405408344_3841093685_init();
    unisims_ver_m_00000000004221170615_0679316750_init();
    unisims_ver_m_00000000000236260522_2449448540_init();
    unisims_ver_m_00000000001508379050_3852734344_init();
    unisims_ver_m_00000000002444920515_2091797430_init();
    unisims_ver_m_00000000001108370118_2467748173_init();
    unisims_ver_m_00000000001108370118_3102277666_init();
    unisims_ver_m_00000000001108370118_4132015673_init();
    unisims_ver_m_00000000001108370118_2639295204_init();
    unisims_ver_m_00000000001108370118_0861236213_init();
    unisims_ver_m_00000000001347610518_3459089569_init();
    unisims_ver_m_00000000002142219875_3378826912_init();
    unisims_ver_m_00000000002142219875_1925941802_init();
    unisims_ver_m_00000000000909115699_2771340377_init();
    unisims_ver_m_00000000003848737514_1058825862_init();
    work_m_00000000004229752133_0483295857_init();
    ieee_p_2592010699_init();
    ieee_p_3499444699_init();
    ieee_p_0774719531_init();
    ieee_p_1242562249_init();
    std_textio_init();
    ieee_p_3564397177_init();
    vl_p_2533777724_init();
    work_a_1132065030_3212880686_init();
    work_a_2921116039_2372691052_init();


    xsi_register_tops("work_a_2921116039_2372691052");
    xsi_register_tops("work_m_00000000004134447467_2073120511");

    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    IEEE_P_0774719531 = xsi_get_engine_memory("ieee_p_0774719531");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    STD_TEXTIO = xsi_get_engine_memory("std_textio");
    IEEE_P_3564397177 = xsi_get_engine_memory("ieee_p_3564397177");
    VL_P_2533777724 = xsi_get_engine_memory("vl_p_2533777724");

    return xsi_run_simulation(argc, argv);

}
